# spectagram-stage-6
project solution for c86
